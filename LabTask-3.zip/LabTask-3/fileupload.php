<!DOCTYPE html>

<html>
<head>
  <title>Profile Picture</title>
</head>
<body>

  <form action = "upload.php" method="POST" enctype ="multipart/form-data">
    <p><input type="file" name="fille"/></p>
  <button type="submit" name="submit">UPLOAD</button> 

    
   </form>

</body>
</html>