<?php
if (isset($_POST['submit'])){
$file = $_FILES['file'];
$fileName = $_FILES['file']['name'];
$fileTmpName = $_FILES['file']['tmp_name'];
$filesize = $_FILES['file']['size'];
$fileError = $_FILES['file']['error'];
$fileType = $_FILES['file']['type'];

$fileExt = explode('.', $filename);
$fileActualExt - strtolower(end($fileExt));

$allowed = array('jpg', 'jpeg', 'png');
if(in_array($fileActualExt, $allowed)) {
	if ($fileError == 0) {
		if ($filesize < 400000) {
            $fileNameNEW = uniqid('', true).".".$fileActualExt;
            $fileDestination = 'uploads/'.$fileNameNEW;
            move_uploaded_file($fileTmpName, fileDestination);
            header("Location: index.php?uploadsuccess");
		} else {
			echo "Your file is too much big!";
		}

	} else {
		echo "There was an errpr uploading file!";
	}
} else {
	echo "You cannot upload files of this type ";
}

}
