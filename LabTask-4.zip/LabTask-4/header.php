
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<?php
echo '
<a href="login.php">Log In</a> -
<a href="register.php">Registration</a> -
<a href="welcome.php">Home</a>';

?>

</body>
</html>