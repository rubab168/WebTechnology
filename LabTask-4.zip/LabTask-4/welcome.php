<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<div class="header">
<?php include 'header.php';?>
</div>

<h1>Welcome to my home page!</h1>

<?php include 'footer.php';?>
</body>
</html>