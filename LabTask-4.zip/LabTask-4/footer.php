
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<?php
echo "<p>Copyright &copy; 2017";
?>

</body>
</html>